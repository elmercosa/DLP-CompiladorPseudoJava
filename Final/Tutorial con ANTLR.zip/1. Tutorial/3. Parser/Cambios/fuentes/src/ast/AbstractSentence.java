/**
 * @generated VGen (for ANTLR) 1.7.0
 */

package ast;

public abstract class AbstractSentence extends AbstractAST implements Sentence {

}
