package visitor;

/**
 * DefaultVisitor. Implementación base del visitor para ser derivada por nuevos visitor.
 *
 *  Esta clase se completará en la fase de Análisis Sintáctico.
 */
public class DefaultVisitor implements Visitor {

    // public Object visit(Programa nodo, Object param) {
    // ...
    // }

}
