Elmer Cortez Sanjinez - UO257192
Ejecutar main para generar el arbol, nombre del fichero ya incluido en la clase.